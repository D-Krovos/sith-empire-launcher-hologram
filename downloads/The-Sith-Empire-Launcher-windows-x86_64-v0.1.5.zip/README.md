## Downloads

- **Windows x64:** download `The {{S}} Launcher-windows-x86_64.zip`, extract it, and run `The {{S}} Launcher.exe`.
- **Linux x64:** download `The {{S}} Launcher-linux-x86_64.tar.gz`, extract it, and run `./'The {{S}} Launcher'`. The archive preserves executable permissions. This is a native Linux executable built on Ubuntu 22.04, not a Windows EXE or an AppImage.
- `SHA256SUMS.txt` contains SHA-256 checksums for the downloads.

Both archives preserve the launcher's official `The {{S}} Launcher` executable name.

## Setup

Select your Jedi Academy **GameData** folder using **Change…**. The **Client Launcher** Sith hologram starts the detected client. Choose another detected client, or browse for a custom executable, in **Settings → Jedi Academy client**. The JoF card installs and updates JoF EternalJK; **Verify PK3s** checks selected cloud content.

Jedi Academy's original game files and a working game client are required and are not included. Launcher artwork is embedded in the executable.

On Ubuntu 22.04 or newer, install the Linux desktop libraries if needed:

```sh
sudo apt-get install libgtk-3-0 libxdo3 libayatana-appindicator3-1 libxkbcommon0 libgl1
tar -xzf 'The {{S}} Launcher-linux-x86_64.tar.gz'
./'The {{S}} Launcher'
```

Other distributions need equivalent packages and glibc 2.35 or newer. A graphical desktop session is required.
